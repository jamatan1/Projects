var video;
var rads = 0;
var photos;
function setup() {
  canvas = createCanvas(640*2, 480);
  video = createCapture(VIDEO);
  video.hide();
  rads = 0;
  photos = [];
}

function draw() {
  background('white');
  image(video, 0, 0, width, height);
  if(frameCount % 30 === 0){
    photos[i % 70] = video;
  }
  image(photos[0], 641, 0, width, height);
}
