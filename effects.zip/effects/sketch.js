
var canvas;
var graphics;
var video;
var serious;
var bg;
function preload(){
  video = createVideo("libraries/dog.mp4", confirmLoad);
  bg = createVideo("libraries/background.mp4", confirmLoad);
}
function setup() {

  canvas = createCanvas(640, 480);
  canvas.id('p5canvas');


  serious = createGraphics(640, 480, WEBGL);
  serious.size(640, 480);
  serious.id('seriouscanvas');
  serious.hide();

  video.id("mainvideo");
  video.size(640, 480);
  video.loop();
  video.hide();
  playVideo(video);

  bg.id("bgvideo");
  bg.size(640, 480);
  bg.hide();
  playVideo(bg);


  graphics = createGraphics(640, 480);
  graphics.size(640, 480);
  graphics.id('graphicscanvas');
  graphics.hide();

  var seriously = new Seriously();

  /*var trans = seriously.transform('reformat');
  trans.width = width;
  trans.height = height;*/

  var src = seriously.source('#mainvideo');
  var target = seriously.target('#seriouscanvas');
  var chroma = seriously.effect('chroma');

  target.source = chroma;
  chroma.source = src;

  seriously.go();
}

function confirmLoad() {
  console.log("Video loaded.");
}

function playVideo(vid){
  vid.play();
}

function draw() {
  image(bg, 0, 0);
  image(serious, mouseX, mouseY, 100, 100);
}
